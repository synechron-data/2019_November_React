import React, { Component } from 'react';

class Button extends Component {
    constructor(props) {
        super(props);
        this.state = { id: 1, count: 0 };
    }

    handleClick() {
        // alert("Button was Clicked....");
        // console.log(this);
        // this.state.count += 1;
        this.setState({ count: this.state.count + 1 }, () => {
            console.log(this.state);
        });
    }

    render() {
        return (
            <div>
                <h2 className="text-warning">Id: {this.state.id}</h2>
                <h2 className="text-warning">Count: {this.state.count}</h2>
                <button className="btn btn-primary" onClick={this.handleClick.bind(this)}>Click to Change</button>
            </div>
        );
    }
}

export default Button;