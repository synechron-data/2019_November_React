import 'bootstrap/scss/bootstrap.scss';

import React from 'react';
import ReactDOM from 'react-dom';
import 'jquery';
import 'bootstrap';
import { BrowserRouter, Router } from 'react-router-dom';
import history from './history';

import './index.css';
import RootComponent from './components/root/RootComponent';
import configureStore from './store/configureStore';
import { Provider } from 'react-redux';

const appStore = configureStore();
// const appStore = configureStore({ 0: 1000 });

// ReactDOM.render(<Provider store={appStore}>
//     <BrowserRouter>
//         <RootComponent />
//     </BrowserRouter>
// </Provider>, document.getElementById('root'));

ReactDOM.render(<Provider store={appStore}>
    <Router history={history}>
        <RootComponent />
    </Router>
</Provider>, document.getElementById('root'));
