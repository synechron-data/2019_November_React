import React, { Component } from 'react';
import { connect } from 'react-redux';

import * as productActions from '../../actions/productActions';

import ProductListComponent from '../../components/products/ProductListComponent';
import LoaderAnimation from '../../components/common/Loader';
import AddProductButton from '../../components/products/AddProductButton';

class ProductsContainer extends Component {
    constructor(props) {
        super(props);
        this.deleteProduct = this.deleteProduct.bind(this);
    }

    deleteProduct(p, e) {
        this.props.deleteProduct(p);
    }

    render() {
        return (
            <React.Fragment>
                {this.props.products.length > 0 ?
                    <React.Fragment>
                        <AddProductButton />
                        <br /><br />
                        <ProductListComponent products={this.props.products}
                            onDelete={this.deleteProduct} />
                    </React.Fragment>
                    :
                    <div className="pt-5">
                        <LoaderAnimation />
                    </div>}
            </React.Fragment>
        );
    }

    componentDidMount() {
        this.props.loadProducts();
    }
}

function mapStateToProps(state, ownProps) {
    return {
        products: state.productReducer.products
    };
}

function mapDispatchToProps(dispatch) {
    return {
        loadProducts: () => { dispatch(productActions.loadProducts()); },
        deleteProduct: (p) => { dispatch(productActions.deleteProduct(p)) }
    };
}

export default connect(mapStateToProps, mapDispatchToProps)(ProductsContainer);