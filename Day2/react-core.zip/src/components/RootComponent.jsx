import React, { Component } from 'react';
import ClassVsFunctional from './1_ClassVsFunctional';
import EventComponent from './2_EventObject';
import CounterAssignment from './3_CounterAssignment';
import DataFlowAssignment from './4_DataFlowAssignment';
import ControlledVsUncontrolled from './5_ControlledVsUncontrolled';
import CalculatorAssignment from './6_CalculatorAssignment';
import ListRoot from './7_ListComponent';
import PropTypeRoot from './8_PropTypes';

class RootComponent extends Component {
    render() {
        return (
            <div className="container">
                {/* <ClassVsFunctional /> */}
                {/* <EventComponent /> */}
                {/* <CounterAssignment /> */}
                {/* <DataFlowAssignment /> */}
                {/* <ControlledVsUncontrolled /> */}
                {/* <CalculatorAssignment /> */}
                {/* <ListRoot /> */}
                <PropTypeRoot />
            </div>
        );
    }
}

export default RootComponent;