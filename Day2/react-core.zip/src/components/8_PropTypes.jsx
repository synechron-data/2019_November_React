import React, { Component } from 'react';
import PropTypes from 'prop-types';

class PropTypesComponent extends Component {
    render() {
        var ename = this.props.name.toUpperCase();
        return (
            <div>
                <h3 className="text-info">Hello, {ename}</h3>
                <h3 className="text-info">Your Postal Code is, {this.props.pcode}</h3>
                <h3 className="text-info">Age, {this.props.age}</h3>
            </div>
        );
    }

    static get propTypes() {
        return {
            name: PropTypes.string.isRequired,
            pcode: PropTypes.number.isRequired,
            // age: PropTypes.number.isRequired
            age: function (props, propName, componentname) {
                if (!props[propName])
                    return new Error(`${componentname} ---- ${propName}, is required...`);
            }
        }
    }
}

class PropTypeRoot extends Component {
    render() {
        return (
            <div>
                <PropTypesComponent name={"manish"} pcode={411021} age={1} />
            </div>
        );
    }
}

export default PropTypeRoot;