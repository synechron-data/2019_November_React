import React, { Component } from 'react';

class ComponentOne extends Component {
    render() {
        console.log(this.state);
        console.log(this.props);
        return (
            <div>
                <h1 className="text-info">Using Class Syntax</h1>
            </div>
        );
    }
}

// Presentation (Stateless Components)
const ComponentTwo = (props) => {
    console.log(props);
    return (
        <div>
            <h1 className="text-info">Using Function Syntax</h1>
        </div>
    );
}

const ComponentThree = ({ id, name, ...args }) => {
    console.log(id);
    console.log(name);
    console.log(args);
    return (
        <div>
            <h1 className="text-info">Using Function Syntax</h1>
        </div>
    );
}

class ClassVsFunctional extends Component {
    render() {
        return (
            <div>
                {/* <ComponentOne /> */}
                {/* <ComponentTwo id={1} name={"Manish"} city={"Pune"} /> */}
                {/* <ComponentThree id={1} name={"Manish"} city={"Pune"} /> */}
            </div>
        );
    }
}

var person = { id: 1, name: "Manish", city: "Pune", state: "MH" };

// var id = person.id;
// var name = person.name;

// ES 2015
// var { id, name } = person;
var { id, name, ...address } = person;

console.log(id);
console.log(name);
console.log(address);

export default ClassVsFunctional;