import React, { Component } from 'react';

class Counter extends Component {
    constructor(props) {
        super(props);
        this.clickCount = 0;
        this.state = { count: 0, flag: false };
        this.inc = this.inc.bind(this);
        this.dec = this.dec.bind(this);
        this.reset = this.reset.bind(this);
    }

    manageClickCount(e) {
        this.clickCount += 1;
        if (this.clickCount > 9) {
            this.setState({ flag: true }, () => {
                this.props.onMax(this.state.flag);
            });
        }
    }

    inc(e) {
        this.manageClickCount(e);
        e.preventDefault();
        this.setState({ count: this.state.count + this.props.interval });
    }

    dec(e) {
        this.manageClickCount(e);
        e.preventDefault();
        this.setState({ count: this.state.count - this.props.interval });
    }

    reset(e) {
        e.preventDefault();
        this.clickCount = 0;
        this.setState({ count: 0, flag: false }, () => {
            this.props.onMax(this.state.flag);
        });
    }

    render() {
        return (
            <React.Fragment>
                <div className="text-center">
                    <h3 className="text-info">Counter Component</h3>
                </div>
                <div className="row d-flex justify-content-center">
                    <div className="col-sm-4">
                        <input type="text" className="form-control" value={this.state.count} readOnly />
                    </div>
                    <div className="col-sm-1">
                        <button className="btn btn-info btn-block" onClick={this.inc}
                            disabled={this.state.flag}>+</button>
                    </div>
                    <div className="col-sm-1">
                        <button className="btn btn-info btn-block" onClick={this.dec}
                            disabled={this.state.flag}>-</button>
                    </div>
                    <div className="col-sm-2">
                        <button className="btn btn-info btn-block" onClick={this.reset}
                            disabled={!this.state.flag}>Reset</button>
                    </div>
                </div>
            </React.Fragment>
        );
    }

    static get defaultProps() {
        return {
            interval: 1
        };
    }
}

class CounterAssignment extends Component {
    constructor(props) {
        super(props);
        this.state = { message: "" };
        this.childRef = React.createRef();
        this.p_reset = this.p_reset.bind(this);
        this.updateMessage = this.updateMessage.bind(this);
    }

    p_reset(e) {
        e.preventDefault();
        // console.log(this.childRef);
        this.childRef.current.reset(e);
    }

    updateMessage(flag) {
        if (flag)
            this.setState({ message: "Max Click Reached, click Reset..." });
        else
            this.setState({ message: "" });
    }

    render() {
        return (
            <React.Fragment>
                <div>
                    <br />
                    {this.state.message ? <div className="alert alert-danger">{this.state.message}</div> : null}
                    <br />
                    <Counter ref={this.childRef} onMax={this.updateMessage} />
                    <br />
                    <div className="text-center">
                        <button className="btn btn-warning btn-block" onClick={this.p_reset}>Parent Reset</button>
                    </div>
                </div>
                {/* <div>
                    <Counter />
                    <br />
                    <Counter interval={5} />
                    <br />
                    <Counter interval={10} />
                    <br />
                    <Counter interval={50} />
                </div> */}
            </React.Fragment>
        );
    }
}

export default CounterAssignment;