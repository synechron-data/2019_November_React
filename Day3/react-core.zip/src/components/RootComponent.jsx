import React, { Component } from 'react';
import Assignment from './1_Assignment';
import ErrorHandler from './common/ErrorHandler';
import AjaxComponent from './2_AjaxComponent';
import PropDrillingComponent from './3_PropDrilling';
import ContextAPIDemo from './4_ContextAPIDemo';

class RootComponent extends Component {
    render() {
        return (
            <div className="container">
                <ErrorHandler>
                    {/* <Assignment /> */}
                    {/* <AjaxComponent /> */}
                    {/* <PropDrillingComponent/> */}
                    <ContextAPIDemo />
                </ErrorHandler>
            </div>
        );
    }
}

export default RootComponent;