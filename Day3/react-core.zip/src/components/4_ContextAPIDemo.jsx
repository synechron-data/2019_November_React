import React, { Component } from 'react';
import DataTable from './common/DataTable';
import postAPIClient from '../services/post.service';

const { Provider, Consumer } = React.createContext();

class ContextAPIDemo extends Component {
    constructor(props) {
        super(props);
        this.state = { posts: [], message: "Loading Data, please wait..." };
    }

    render() {
        return (
            <React.Fragment>
                <h2 className="text-primary">Parent</h2>
                <div className="row">
                    <h4 className="text-warning text-uppercase font-weight-bold">{this.state.message}</h4>
                </div>
                <Provider value={this.state.posts}>
                    <ChildOne />
                </Provider>
            </React.Fragment>
        );
    }

    componentDidMount() {
        postAPIClient.getAllPosts().then((data) => {
            this.setState({ message: "", posts: [...data] });
        }, (eMsg) => {
            this.setState({ message: eMsg });
        })
    }
}

class ChildOne extends Component {
    render() {
        return (
            <div>
                <h3 className="text-info">Child One</h3>
                <ChildTwo />
            </div>
        );
    }
}

class ChildTwo extends Component {
    render() {
        return (
            <div>
                <h3 className="text-info">Child Two</h3>
                <Consumer>
                    {
                        (data) =>
                            <DataTable items={data}>
                                <h4 className="text-primary text-uppercase font-weight-bold">Posts Table</h4>
                            </DataTable>
                    }
                </Consumer>
            </div>
        );
    }
}

export default ContextAPIDemo;