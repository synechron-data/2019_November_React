import React, { Component } from 'react';
import DataTable from './common/DataTable';
import postAPIClient from '../services/post.service';

class AjaxComponent extends Component {
    constructor(props) {
        super(props);
        this.state = { posts: [], message: "Loading Data, please wait..." };
    }

    render() {
        return (
            <React.Fragment>
                <div className="row">
                    <h4 className="text-warning text-uppercase font-weight-bold">{this.state.message}</h4>
                </div>
                <DataTable items={this.state.posts}>
                    <h4 className="text-primary text-uppercase font-weight-bold">Posts Table</h4>
                </DataTable>
            </React.Fragment>
        );
    }

    componentDidMount() {
        postAPIClient.getAllPosts().then((data) => {
            this.setState({ message: "", posts: [...data] });
        }, (eMsg) => {
            this.setState({ message: eMsg });
        })
    }
}

export default AjaxComponent;